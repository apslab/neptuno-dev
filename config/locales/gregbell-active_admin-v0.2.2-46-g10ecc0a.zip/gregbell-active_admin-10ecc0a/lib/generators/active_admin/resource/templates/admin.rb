ActiveAdmin.register <%= class_name.singularize %> do
  
end
