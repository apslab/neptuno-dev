class Object
  def to_html
    to_s
  end
end
