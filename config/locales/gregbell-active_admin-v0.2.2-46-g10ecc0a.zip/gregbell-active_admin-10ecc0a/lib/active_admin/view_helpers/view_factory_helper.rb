module ActiveAdmin
  module ViewHelpers
    module ViewFactoryHelper

      def view_factory
        ActiveAdmin.view_factory
      end

    end
  end
end
