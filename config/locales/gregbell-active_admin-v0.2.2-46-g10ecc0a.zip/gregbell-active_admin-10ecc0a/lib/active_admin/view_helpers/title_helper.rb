module ActiveAdmin
  module ViewHelpers
    module TitleHelper

      def title(_title)
        @page_title = _title 
      end

    end
  end
end
